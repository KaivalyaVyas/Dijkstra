package Project2;

/*
 * Kaivalya Vyas
 * Student id - 800936482
 * */

import java.util.LinkedList;
import java.util.List;

public class Vertex {

	    public String     name;   // Vertex name
	    public List<Vertex> adj;    // Adjacent vertices
	    public List<Edge> Edgeadj;    // Edges List from vertex
	    public String     prevVrtx;
	    public Vertex     prev;   // Previous vertex on shortest path
	    public float        dist;   // Distance of path
	    public String vertextStatus ; //Vertex Status
	   
	    public Vertex( String nm,float distance ,String status)
	      { name = nm;vertextStatus = status; adj = new LinkedList<Vertex>( );Edgeadj = new LinkedList<Edge>(); reset(distance ); }

	    public void reset( float distance)
	      { dist = Integer.MAX_VALUE; prev = null; }    


}
