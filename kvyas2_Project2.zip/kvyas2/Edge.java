package Project2;
/*
 * Kaivalya Vyas
 * Student id - 800936482
 * */
public class Edge {
	
public String FromVertex;
public String ToVertex;
public float distance;
public String status;

public Edge(String fromVertex, String toVertex, float distance, String status) {
	super();
	FromVertex = fromVertex;
	ToVertex = toVertex;
	this.distance = distance;
	this.status = status;
}
public String getFromVertex() {
	return FromVertex;
}
public void setFromVertex(String fromVertex) {
	FromVertex = fromVertex;
}
public String getToVertex() {
	return ToVertex;
}
public void setToVertex(String toVertex) {
	ToVertex = toVertex;
}
public float getDistance() {
	return distance;
}
public void setDistance(float distance) {
	this.distance = distance;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}



}
