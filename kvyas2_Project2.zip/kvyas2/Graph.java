package Project2;
/*
 * Kaivalya Vyas
 * Student id - 800936482
 * */
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

public class Graph {
	   public static final int INFINITY = Integer.MAX_VALUE;
	    private static Map<String,Vertex> vertexMap = new HashMap<String,Vertex>( );
	    private static Map<String,Edge> EdgeMap = new HashMap<String,Edge>( );
	   private static String tempTgt = "|" ;
	   private static float tempDist = 0;
	    //static String [] table = new String[vertexMap.size()];
         static ArrayList<String> table = new ArrayList<String>();
	    /**
	     * Add a new edge to the graph.
	     * And Add Edge in Adgecency List
	     */
	    
	       
	    
	    public void addEdge( String sourceName, String destName ,float dist_new)
	    {
	    	
	    	
	        Vertex v = getVertex( sourceName,dist_new );
	        Vertex w = getVertex( destName,dist_new );
	        Edge e = new Edge(sourceName,destName,dist_new,"UP");
	        v.Edgeadj.add(e);
	    	
	        
	    }
	
	    
	    /**
	     *mark vertex as up 
	     * 
	     * @param vertexName
	     */
	    public void upvertex(String vertexName)
	    {
	    	Iterator iterator = vertexMap.keySet().iterator();
	    	while(iterator.hasNext())
	    	{
	    		String key = iterator.next().toString();
	    		if(key.equals(vertexName)){
	    		Vertex vrtx = vertexMap.get(key);
	    		vrtx.vertextStatus = "UP";
	    	}
	    	}
	    }
	    
	    /**
	     *mark vertex as down
	     * 
	     * @param vertexName
	     */
	    public void downvertex(String vertexName)
	    {
	    	
	    	
	    	Iterator iterator1 = vertexMap.keySet().iterator();
	    
	    	System.out.println("size"+vertexMap.size());
	    	while(iterator1.hasNext())
	    	{
	    		
	    		String key = iterator1.next().toString();
	    		
	    		if(key.equals(vertexName))
	    		{
	    		Vertex vrtx = vertexMap.get(key);
	    		vrtx.vertextStatus = "DOWN";
	    		}
	    	}
	    }
	    
	    
	    /**
	     * delete edge
	     * */
	    
	    public void deleteEdge(String srcvrtx, String tgtVertex)
	    {
	    	 Vertex v = vertexMap.get(srcvrtx);
	    	 if(v == null)
	    	 {
	    		 System.out.println("Edge is not present to delete");
	    	 }
	    	if(v != null)
	    	{
	    	 for(int i =0;i<v.Edgeadj.size();i++)
	    	 {
	    			
	    		 if(v.Edgeadj.get(i).ToVertex.toString().equals(tgtVertex.toString()) )
	    		 {
	    			
	    			 v.Edgeadj.remove(i);
	    		 }
	    	 }
	    	}
	    }

/*  
 * mark edge as down
 *  */	   
	    
	    public void downEdge(String srcvrtx, String tgtVertex)
	    {
	    	
	    	 Vertex v = vertexMap.get(srcvrtx.trim());
	    	// System.out.println(""+v.Edgeadj.size());
	    	 
	    	 if(v == null)
	    	 {
	    		 System.out.println("Edge is not present to down");
	    	 }
	    	if(v!=null){
	    	 for(int i =0;i<v.Edgeadj.size();i++)
	    	 {
	    		
	    		 if(v.Edgeadj.get(i).ToVertex.toString().equals(tgtVertex.toString()) )
	    		 {
	    			
	    			 v.Edgeadj.get(i).status = "DOWN";
	    		 }
	    	 }}
	    }
	 
	    /*  
	     * mark edge as up
	     *  */	
	    
	    public void upEdge(String srcvrtx, String tgtVertex)
	    {
	    	 Vertex v = vertexMap.get(srcvrtx);
	    	 if(v == null)
	    	 {
	    		 System.out.println("Edge is not present to down");
	    	 }
	    	
	    	 for(int i =0;i<v.Edgeadj.size();i++)
	    	 {
	    			
	    		 if(v.Edgeadj.get(i).ToVertex.toString().equals(tgtVertex.toString()) )
	    		 {
	    			 if(v.Edgeadj.get(i).status.equals("DOWN"))
	    			 {
	    				 v.Edgeadj.get(i).status = "UP";	 
	    			 }
	    			 else
	    			 {
	    				 System.out.println("Opps!! Edge is already up");
	    			 }
	    			
	    		 }
	    	 }
	    }

/*
 * Finding reachable vertexlist from given vertex takes  O(V+E) time for graph G(V,E) 
 * one loop that takes O(V) time to identify vertex place 
 * another loop takes O(E) time to identify all attached("REACHABLE") vertexes from it 
 * so maximum time is O(V+E)
 * 
 */
	    public void reachableVertex(Map<String, Vertex> treeMap1)
	    {
	    	
	    	
	  	  Iterator iterator = treeMap1.keySet().iterator();

     	 while (iterator.hasNext()) {
     	    String key = iterator.next().toString();
     	    
     	   Vertex v = treeMap1.get(key);
     	   
     	   if(v.vertextStatus.equals("UP")){
     	   System.out.println(" "+v.name);
     	  for(int i =0;i<v.Edgeadj.size();i++)
	    	{
     		 List l = v.Edgeadj;
     		
     		  Collections.sort(l,new Comparator<Edge>(){

				@Override
				public int compare(Edge o1, Edge o2) {
					// TODO Auto-generated method stub
					 
					int temp = o1.ToVertex.compareTo(o2.ToVertex);
					if(temp<0)
					{
						//System.out.println("in compar");
					}if(temp>0)
					{
						//System.out.println("in compar");
					}
					else
					{
						//System.out.println("in compar");
					}
					
					
					return temp;
				}
     			  
     		  });

	    	  
	    	 if(v.Edgeadj.get(i).status.equals("UP") ) 
	    	 {
	    		 System.out.println("    "+v.Edgeadj.get(i).ToVertex);
	    	 }
	    	}
	    	}
     	 }
	    	
	    	
	    	/**/
	    }
	  
	    /**
	     * If vertexName is not present, add it to vertexMap.
	     * In either case, return the Vertex.
	     */
	    private Vertex getVertex( String vertexName,float distance )
	    {
	    	// System.out.println("dist11"+distance_new);
	        Vertex v = vertexMap.get( vertexName );
	        if( v == null )
	        {
	        	
	            v = new Vertex( vertexName, distance,"UP");
	            vertexMap.put( vertexName, v );
	        }
	        
	      //  System.out.println("dist"+vertexMap.get(vertexName).distance_new);
	        return v;
	    }
	    
	    
	  
	    /**
	     * Prints Graph
	     * 
	     */
        public void printGraph(Map<String, Vertex>  treeMapP)
        {
        	  Iterator iterator = treeMapP.keySet().iterator();

	        	 while (iterator.hasNext()) {
	        	    String key = iterator.next().toString();
	        	    Vertex v = treeMapP.get(key);
                      String vtxStatus = "";
	        	       if(v.vertextStatus.equals("DOWN"))
                      {
	        	    	   vtxStatus = "DOWN";
                      }
	        	    
	        	    System.out.println(key+" "+vtxStatus);
	        	   
	        	    
	        	    for(int i =0;i<v.Edgeadj.size();i++){
	        	    	String edgeStatus="";
	        	    	 
		        	    List l = v.Edgeadj;
		         		
		       		  Collections.sort(l,new Comparator<Edge>(){

		  				@Override
		  				public int compare(Edge o1, Edge o2) {
		  					// TODO Auto-generated method stub
		  					 
		  					int temp = o1.ToVertex.compareTo(o2.ToVertex);
		  					if(temp<0)
		  					{
		  						//System.out.println("in compar");
		  					}if(temp>0)
		  					{
		  						//System.out.println("in compar");
		  					}
		  					else
		  					{
		  						//System.out.println("in compar");
		  					}
		  					
		  					
		  					return temp;
		  				}
		       			  
		       		  });

	        	    	
	        	    	if(v.Edgeadj.get(i).status.equals("DOWN"))
	        	    	{
	        	    		//System.out.println("KDVmarking edge down");
	        	    		edgeStatus = v.Edgeadj.get(i).status;
	        	    	}
	        	    	
	        	    System.out.println("  "+v.Edgeadj.get(i).ToVertex+" "+v.Edgeadj.get(i).distance+"  "+edgeStatus);
	        	    }
	        
	         }

        	 System.out.println("-------------Printed Graph------------");	
        }
	  
	
        //Below method takes sorted array List with Map and produces table of shortest path w.r.t source node
        
        public static ArrayList<Vertex> Dijkstrarevised (int src,ArrayList<Vertex> al,Map<String,Vertex> vrtx)
        {
        	
        	for(int i=0;i<al.size();i++)
        	{
        		al.get(i).dist = Integer.MAX_VALUE;
        		//al.get(i).prevVrtx = "";
        		
        	}
        	
        	ArrayList<Vertex> visited = new ArrayList<Vertex>();
        	System.out.println("IMP"+al.size());
        	al.get(src).dist = 0;
        	al.get(src).prevVrtx = "";
        	al= comparatorFn(al);
        	tempTgt = "|";
        	tempDist = 0;
        	for(int i=0;i<al.size();i++)
        	{
        		//System.out.println(al.get(i).name+"--b4--"+al.get(i).dist);
        	}
        	while(al.size()>0)
        	{  al= comparatorFn(al);
        		//System.out.println("new intr");
        		
        		int k=0;//k is just to add min node in it
        		visited.add(k,al.get(0));
        		
        		//remove if something goes wrong
        		al.set(0,al.get(al.size()-1));
        		al.remove(al.get(al.size()-1));
        		al = extractMin(al,0);
        		
        	//	al.remove(0);  //restore if something wents wrong
        //		al= comparatorFn(al);  // restore if something wents wrong
        		//System.out.println("SRCC"+visited.get(0).name);
        		//System.out.println("SRCC"+visited.size());
        		for(int adjSize=0;adjSize<visited.get(0).Edgeadj.size();adjSize++)
            	{
        			if(visited.get(k).vertextStatus != "DOWN" ){
        				
        				if(visited.get(k).Edgeadj.get(adjSize).status != "DOWN"){
        				
        		//	System.out.println("adj vrtx "+visited.get(0).Edgeadj.get(adjSize).ToVertex);
        		//	System.out.println("u"+visited.get(0).dist);
        		//	System.out.println("Edge"+visited.get(0).Edgeadj.get(adjSize).distance);
        		//	System.out.println("V"+vrtx.get(  visited.get(0).Edgeadj.get(adjSize).ToVertex    ).dist);
        			int dest = -1;
        			for(int i =0; i<al.size();i++)
        			{
        				if(al.get(i).name.equals(visited.get(0).Edgeadj.get(adjSize).ToVertex))
        				{
        				   dest = i;
        				}
        			}
        			
        			if(dest>=0)
        			{
        				//System.out.println("V"+al.get(dest).dist);
        			}
        			System.out.println(dest+"--"+al.size());
        		if((dest>=0) && visited.get(0).dist+visited.get(0).Edgeadj.get(adjSize).distance<al.get(dest).dist)
        			
        		{
        			al.get(dest).dist = visited.get(0).dist+visited.get(0).Edgeadj.get(adjSize).distance;
        			al.get(dest).prevVrtx = visited.get(0).name;
        			al = DecreaseKey(al,dest);  //min heap decrease key
        		}
        			
        			}}
            	}
        		//al= comparatorFn(al);   //called  without min heap restore if  DecreaseKey not working
        		k = k+1;
        	}	        	
        	return visited;
        }
       
        
        //below mathod calls dijkstra revised method and then gives shortes path by recursivepath method
        
        public static String findShortestPath(Map<String,Vertex> vertex, String src , String tgt)
        {
        	
        	 ArrayList<Vertex> vAl = new ArrayList<Vertex>();
	    	  Iterator iterator2 = vertex.keySet().iterator();
	    	  
		    	while(iterator2.hasNext())
		    	{
		    		String key = iterator2.next().toString();
		    		Vertex vrtx = vertex.get(key);
		    		if(vrtx.vertextStatus != "DOWN" ){
		    		vAl.add(vrtx);
		    		
		    		}
		    	
		    	
		    	}
		    	//System.out.println("VALSIZE"+vAl.size());
		  int srcint=-1 ;
		  for(int i =0;i<vAl.size();i++)
		  {
			  if(vAl.get(i).name.equals(src))
			  {
				  srcint=i;
			  }
		  }
		    	
		 ArrayList<Vertex> v = Dijkstrarevised(srcint,vAl,vertexMap); 
		 
		
		 
		 
		HashMap<Integer,Vertex> hmap = new HashMap(); 
		System.out.println(src+" to "+tgt);
		 for(int l=0;l<v.size();l++ )
			{
			 //System.out.println(src+" and "+tgt);
				System.out.println("Src  "+v.get(l).name+"|"+v.get(l).dist+"|"+v.get(l).prevVrtx);
			   hmap.put(l, v.get(l));
			}
        	
		
		
		 	    	
		 
        	return findPathrecursion(hmap,tgt).replace("|", "  ");
        }
        
//below method gives path in string form
        public static String findPathrecursion(Map<Integer,Vertex> v,String tgtRec)
        {
        		 
         	  Iterator iterator3 = v.keySet().iterator();
          
        	String x = tgtRec;
        	while(iterator3.hasNext())
	    	{
	    		Integer key = (Integer)iterator3.next();
	    		
	    		
	    		
	    		if(tgtRec.equals(v.get(key).name) && (tgtRec!= null && !tgtRec.trim().isEmpty()))
	    		{
	    			//System.out.println(v.get(key).name+"--"+v.get(key).prevVrtx+"--"+v.get(key).dist);
	    			tgtRec = v.get(key).prevVrtx;
	    			//tempTgt.concat(tgtRec);
	    	//		System.out.println("in recursion"+tgtRec);
	    			if(tempDist<v.get(key).dist)
	    			{tempDist = v.get(key).dist;}
	    			try
	    			{
	    			if(tgtRec.isEmpty()){tgtRec= Float.toString(tempDist);};
	    			}
	    			catch (Exception e)
	    			{
	    			
	    				System.out.println("No Path and Distance available");
	    			}
	    			tempTgt = tempTgt.concat(tgtRec).concat("|");
	    		//	System.out.println(""+tempTgt);
	    			
	    		//	System.out.println(""+tempDist);
	    			tgtRec = (findPathrecursion(v,tgtRec));
	    			
	    		}
	    	
	    	}
        	
        	return x.concat(tempTgt);
        }
        
        //Below method creates min heap and gives sorted array list based on unsorted input. Min Heap is created in O(n) time
        //also it is recusrsive method
        
        public static ArrayList<Vertex> comparatorFn(ArrayList<Vertex> al)
        {
        	//System.out.println("compare al size"+al.size());
        	int size = al.size()-1;
        	int startnode = (int) Math.floor((size-1)/2);
        	
        	for(int i =startnode;i>=0;i--)
    		{
    		//	System.out.println("Start node"+i);
    			int leftchild = 2*i+1;
    			int rightChild = 2*i+2;
    			
    		   if(rightChild>size && (leftchild<=size) ){
    			//  System.out.println("Exceptional"+al.get(0).dist);
    		 if( (al.get(leftchild).dist<al.get(i).dist)){
    			 Vertex v = al.get(i);
    			 al.set(i, al.get(leftchild));
    			 al.set(leftchild, v);
    		 }}
    		 if(rightChild<=size)
    		 {
    			 //System.out.println("NOrmal Scenario");
    			 
    			 if(al.get(leftchild).dist<al.get(i).dist  || al.get(rightChild).dist<al.get(i).dist) 
    			 {
    				 int temp = 0;
    				 if(2*rightChild+2<al.size() || 2*rightChild+1<al.size()  )
    				 {
    					 //System.out.println("big0");
    					 temp =1;
    				 }
    				 if(2*leftchild+1<al.size() || 2*leftchild+2<al.size())
    				 {
    					 //System.out.println("big1");
    					 temp =2;
    				 }
    			   if(al.get(leftchild).dist<al.get(rightChild).dist   && al.get(leftchild).dist<al.get(i).dist )
    			   {
    				//   System.out.println("Left small"+i);
    				   Vertex v = al.get(i);
    				   //System.out.println("LReplacing parent"+v.name);
    				   //System.out.println("LReplacing l chilc"+al.get(leftchild).name);
    	    			 al.set(i, al.get(leftchild));
    	    			 al.set(leftchild, v);
    	    			// al = comparatorFn(al);
    	    			 if(temp!=0){
        	    			 al = comparatorFn(al);}
    			   }
    				 
    			   if(al.get(rightChild).dist<al.get(leftchild).dist && al.get(rightChild).dist<al.get(i).dist)
    			   {
    				   //System.out.println("right small"+i);
    				   Vertex v = al.get(i);
    				   //System.out.println("R replacing parent"+v.name);
    				   //System.out.println("R replacing R child"+al.get(rightChild).name);
    	    			
    	    			 al.set(i, al.get(rightChild));
    	    			 al.set(rightChild, v);
    	    		if(temp!=0){
    	    			
    	    			 al = comparatorFn(al);
    	    			 
    	    		}
    			   }
    				  
    				 
    				 
    			 }
    			 
    		 }
    		 
    		}
        	return al;
        	
        }
        
        
        //Below method is applied after minimum distance node removel. It restores min heap property after removal
        //method takes O(log(n)) time for same.
        
        public static ArrayList<Vertex> extractMin (ArrayList<Vertex> al,int nodeIndex)
        {
        	
        	int leftChildIndex, rightChildIndex, minIndex;
        	float tmp;
            leftChildIndex = 2*nodeIndex+1;
            rightChildIndex = 2*nodeIndex+2;;
            if (rightChildIndex >= al.size()) {
                  if (leftChildIndex >= al.size())
                        return al;
                  else
                        minIndex = leftChildIndex;
            } else {
                  if ( al.get(leftChildIndex).dist <= al.get(rightChildIndex).dist)
                        minIndex = leftChildIndex;
                  else
                        minIndex = rightChildIndex;
            }
            if (al.get(nodeIndex).dist > al.get(minIndex).dist) {
                  tmp = al.get(minIndex).dist;
                  al.get(minIndex).dist = al.get(nodeIndex).dist; 
                   al.get(nodeIndex).dist  = tmp;
               al =    extractMin(al,minIndex);
            }
            return al;
      }

        //after edges value updation below method is called to insure min heap property. O(log(n)) time is complexity 
        
        
      public static ArrayList<Vertex> DecreaseKey (ArrayList<Vertex> al,int node)
      {
    	  //no need to check for child as only lower distance will come so
    	  //find paretn by celing of node/2
    	  //find value of parent and if new value is less then parent then swap it and call Decrease key for ots paretn as well
    	  
    	  
    	  int parentNode = (int) Math.floor(node/2);
    	  
    	  if(al.get(parentNode).dist> al.get(node).dist)
    	  {
    		 Vertex v = al.get(parentNode);
    		 Vertex vchild = al.get(node);
    		 al.set(parentNode, vchild);
    		 al.set(node, v); 
    		 al = DecreaseKey(al,parentNode);
    	  }
    	  
    	  
    	  return al;
      }

	      /**
	     * A main routine that:
	     * 1. Reads a file containing edges (supplied as a command-line parameter);
	     * 2. Forms the graph;
	     * 3. Repeatedly prompts for two vertices and
	     *    runs the shortest path algorithm.
	     * The data file is a sequence of lines of the format
	     *    source destination 
	     */
	    public static void main( String [ ] args )
	    {
	        Graph g = new Graph( );
	        Graph gr =   new  Graph();
	        try
	        {
	        	Scanner scanner = new Scanner(System.in);
	        	System.out.print("Enter Command :");
	            String sentence = scanner.nextLine();
	            
	            while(!sentence.contains("quit"))
	            {
	            	
	            	//System.out.println("while");
	            	  String[] s = sentence.split(" ",4);
	  	            /*System.out.println(""+s[0]);
	  	            if(s.length>1){
	  	            System.out.println(""+s[1]);
	  	            }
	  	            if(s.length>2){
	  	            System.out.println(""+s[2]);
	  	            }*/
	  	           
	  	            if(s[0].equals("graph"))
	  	            {
	  	            	//System.out.println("in graph");
	  	            	
	  		            FileReader fin = new FileReader( s[1]);
	  		            Scanner graphFile = new Scanner( fin );

	  		            // Read the edges and insert
	  		            String line;
	  		            while( graphFile.hasNextLine( ) )
	  		            {
	  		                line = graphFile.nextLine( );
	  		                StringTokenizer st = new StringTokenizer( line );
	  	                    try
	  		                {
	  		                    if( st.countTokens( ) != 3 )
	  		                    {
	  		                      //  System.err.println( "Skipping ill-formatted line 1 " + line );
	  		                        continue;
	  		                    }
	  		                    String source  = st.nextToken( );
	  		                    String dest    = st.nextToken( );
	  		                     float destDist = Float.parseFloat(st.nextToken( ));
	  		                     
	  	                        g.addEdge(dest, source, destDist);    //making graph bidirectional	       
	  		                    g.addEdge( source, dest,destDist);
	  		                }
	  		                catch( NumberFormatException e )
	  		                  { System.err.println( "Skipping ill-formatted line " + line ); }
	  		             }
	  	            	
	  			         System.out.println( "File read..." );
	  			         System.out.println( g.vertexMap.size( ) + " vertices" );

	  	            }
	  	            if(s[0].equals("path"))
	  	            {
	  	            	//System.out.println("in path");
	  	            	
	  	            	Map<String,Vertex> vertexMaptemp = new HashMap<String,Vertex>( );
	  	            	vertexMaptemp = vertexMap;
	  	    	      //--to sp find
	  	    	      String s1 = findShortestPath(vertexMap,s[1],s[2]);
	  	    		  System.out.println("Shortest Path "+s1);
	  	            	
	  	            	
	  	            }
	  	            if(s[0].equals("print"))
	  	            {
	  	            	//System.out.println("in print");
	  	              //---print graph
	  	    	        Map<String, Vertex> unsortMap = vertexMap;
	  	    		    Map<String, Vertex> treeMap = new TreeMap<String, Vertex>(unsortMap);  
	  	    	        gr.printGraph(treeMap);
	  	            }
	  	            if(s[0].equals("reachable"))
	  	            {
	  	            	//System.out.println("in reachable");
	  	          	//----to reachable vertex
	  	      	    Map<String, Vertex> unsortMap = vertexMap;
	  	      	    Map<String, Vertex> treeMap = new TreeMap<String, Vertex>(unsortMap);
	  	            gr.reachableVertex(treeMap);
	  	                
	  	            }
	  	            if(s[0].equals("quit"))
	  	            {
	  	            	System.exit(0);
	  	            }
	  	           //----------edit graph part
	  	            if(s[0].equals("addedge"))
	  	            {
	  	            	//System.out.println("in add edge");
	  	            	gr.addEdge(s[1], s[2], Float.parseFloat(s[3]));
	  	            }
	  	            
	  	            if(s[0].equals("deleteedge"))
	  	            {
	  	            	//System.out.println("in delete edge");
	  	            	gr.deleteEdge(s[1], s[2]);
	  	            }
	  	            if(s[0].equals("edgedown"))
	  	            {
	  	            	//System.out.println("in edgedown");
	  	            	 //down edge
	  	     	        gr.downEdge(s[1],s[2]);
	  	            }
	  	            
	  	            if(s[0].equals("edgeup"))
	  	            {
	  	            	//System.out.println("in edgeup");
	  	            	gr.upEdge(s[1], s[2]);
	  	            }
	  	            if(s[0].equals("vertexdown"))
	  	            {
	  	            	//System.out.println("in v down");
	  	            //--down Vtxx 
	  	        	   gr.downvertex(s[1]);
	  	            }
	  	            if(s[0].equals("vertexup"))
	  	            {
	  	            	//System.out.println("in v up");
	  	            	gr.upvertex(s[1]);
	  	            }
	  	            if(false)
	  	            {
	  	            	System.out.println(" for loop purpose");
	  	            }
	  	            		
	  	            
	  	            else
	  	            {
	  	            	System.out.print("Enter Command :");
			             sentence = scanner.nextLine();
		            		
	  	            }
	  	         
	            }
	          //  While loop for scanning ends here
	            
	            String s1 = findShortestPath(vertexMap,"Belk","Education");
	    		  System.out.println("Shortest Path "+s1);     
	            
	    		  gr.downvertex("Duke");
	    		  

		            String s2 = findShortestPath(vertexMap,"Belk","Education");
		    		  System.out.println("Shortest Path "+s2);     
		    		  
		    		  String s3 = findShortestPath(vertexMap,"Grigg","Woodward");
		    		  System.out.println("Shortest Path "+s3);   
	            
	         }
	         catch( IOException e )
	           { System.err.println( e ); }

	         
	         
	  
	     
	   
	 
	     
	    
	      
	   
	    
	  

	
	    
		    	    }
	    }
